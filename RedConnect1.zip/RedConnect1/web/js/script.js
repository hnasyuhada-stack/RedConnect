// Placeholder credentials (for demo purposes)
const credentials = {
    username: "admin",
    password: "password123" // Replace with hashed credentials in real-world applications
};

// Login function
function login(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username === credentials.username && password === credentials.password) {
        alert("Login successful!");
        window.location.href = "index.jsp"; // Redirect to the homepage
    } else {
        alert("Invalid username or password!");
    }
}


// Toggle Password Visibility
const togglePassword = document.getElementById("toggle-password");
const passwordInput = document.getElementById("password");

togglePassword.addEventListener("click", () => {
    const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
    passwordInput.setAttribute("type", type);
    togglePassword.textContent = type === "password" ? "👁" : "👁‍🗨"; // Icon toggle
});

// Add event listener for form submission
document.getElementById("login-form").addEventListener("submit", login);

// Logout Function
function logout() {
    alert("You have been logged out.");
    window.location.href = "index.jsp"; // Redirect to the login page
}


// Logout Function
function logout() {
    alert("You have been logged out.");
    window.location.href = "index.jsp"; // Redirect to the login page
}


