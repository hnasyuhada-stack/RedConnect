
const credentials = {
    username: "admin",
    password: "123"
};

document.getElementById("login-form").addEventListener("submit", function (event) {
    event.preventDefault(); 

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const errorMessage = document.getElementById("error-message");


    errorMessage.style.display = "none";


    if (username === credentials.username && password === credentials.password) {
        
        window.location.href = "index.jsp";
    } else {
        errorMessage.style.display = "block";
        errorMessage.textContent = "Invalid username or password. Please try again.";
    }
});
