package com.redconnect1.model;

import java.time.LocalDate;

public class Donor {
    private int id;
    private String name;
    private String icNumber;
    private LocalDate dob;
    private String gender;
    private int age;
    private String bloodGroup;
    private String email;
    private String contactNumber;
    private String address;
    private LocalDate donationDate;
    private String donationLocation;
    private int volume;
    private String remarks;

    // Default Constructor
    public Donor() {
    }

    // Parameterized Constructor
    public Donor(int id, String name, String icNumber, LocalDate dob, String gender, int age, String bloodGroup,
                 String email, String contactNumber, String address, LocalDate donationDate, String donationLocation,
                 int volume, String remarks) {
        this.id = id;
        this.name = name;
        this.icNumber = icNumber;
        this.dob = dob;
        this.gender = gender;
        this.age = age;
        this.bloodGroup = bloodGroup;
        this.email = email;
        this.contactNumber = contactNumber;
        this.address = address;
        this.donationDate = donationDate;
        this.donationLocation = donationLocation;
        this.volume = volume;
        this.remarks = remarks;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcNumber() {
        return icNumber;
    }

    public void setIcNumber(String icNumber) {
        this.icNumber = icNumber;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDate getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(LocalDate donationDate) {
        this.donationDate = donationDate;
    }

    public String getDonationLocation() {
        return donationLocation;
    }

    public void setDonationLocation(String donationLocation) {
        this.donationLocation = donationLocation;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
