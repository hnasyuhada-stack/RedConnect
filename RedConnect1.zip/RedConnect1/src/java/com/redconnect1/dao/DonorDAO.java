package com.redconnect1.dao;

import com.redconnect1.model.Donor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DonorDAO {
    private final Connection connection;
    private static final Logger LOGGER = Logger.getLogger(DonorDAO.class.getName());

    public DonorDAO(Connection connection) {
        this.connection = connection;
    }

public DonorDAO() {
    try {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        this.connection = DriverManager.getConnection(
            "jdbc:derby://localhost:1527/redconnect1", "app", "app"
        );
        LOGGER.log(Level.INFO, "Database connection initialized successfully.");
    } catch (ClassNotFoundException | SQLException e) {
        LOGGER.log(Level.SEVERE, "Failed to initialize DonorDAO: {0}", e.getMessage());
        throw new RuntimeException("Failed to initialize DonorDAO", e);
    }
}
public int getTotalDonors() throws SQLException {
    String query = "SELECT COUNT(*) FROM donors";

    try (Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/redconnect1", "app", "app");
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {

        if (rs.next()) {
            return rs.getInt(1);
        }
    }
    return 0;
}

    // Retrieve a single donor by ID
public Donor getDonorById(int id) throws SQLException {
    String query = "SELECT * FROM donors WHERE id = ?";
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setInt(1, id);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return new Donor(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("ic_number"),
                    rs.getDate("dob").toLocalDate(),
                    rs.getString("gender"),
                    rs.getInt("age"),
                    rs.getString("blood_group"),
                    rs.getString("email"),
                    rs.getString("contact_number"),
                    rs.getString("address"),
                    rs.getDate("donation_date").toLocalDate(),
                    rs.getString("donation_location"),
                    rs.getInt("volume"),
                    rs.getString("remarks")
                );
            }
        }
    }
    return null; 
}

  // Update donor in the database
public void updateDonor(Donor donor) throws SQLException {
    String query = "UPDATE donors SET name = ?, ic_number = ?, dob = ?, gender = ?, age = ?, " +
                   "blood_group = ?, email = ?, contact_number = ?, address = ?, donation_date = ?, " +
                   "donation_location = ?, volume = ?, remarks = ? WHERE id = ?";

    try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/redconnect1", "app", "app");
         PreparedStatement pstmt = connection.prepareStatement(query)) {

        pstmt.setString(1, donor.getName());
        pstmt.setString(2, donor.getIcNumber());
        pstmt.setDate(3, java.sql.Date.valueOf(donor.getDob()));
        pstmt.setString(4, donor.getGender());
        pstmt.setInt(5, donor.getAge());
        pstmt.setString(6, donor.getBloodGroup());
        pstmt.setString(7, donor.getEmail());
        pstmt.setString(8, donor.getContactNumber());
        pstmt.setString(9, donor.getAddress());
        pstmt.setDate(10, java.sql.Date.valueOf(donor.getDonationDate()));
        pstmt.setString(11, donor.getDonationLocation());
        pstmt.setInt(12, donor.getVolume());
        pstmt.setString(13, donor.getRemarks());
        pstmt.setInt(14, donor.getId());

        pstmt.executeUpdate();
    }
}

    // Retrieve all donors
    public List<Donor> getAllDonors() throws SQLException {
        List<Donor> donors = new ArrayList<>();
        String query = "SELECT * FROM donors";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Donor donor = new Donor(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("ic_number"),
                    rs.getDate("dob").toLocalDate(),
                    rs.getString("gender"),
                    rs.getInt("age"),
                    rs.getString("blood_group"),
                    rs.getString("email"),
                    rs.getString("contact_number"),
                    rs.getString("address"),
                    rs.getDate("donation_date").toLocalDate(),
                    rs.getString("donation_location"),
                    rs.getInt("volume"),
                    rs.getString("remarks")
                );
                donors.add(donor);
            }
        }

        return donors;
    }

// Add a new donor to the database
public void addDonor(Donor donor) throws SQLException {
    String query = "INSERT INTO donors (name, ic_number, dob, gender, age, blood_group, email, contact_number, address, donation_date, donation_location, volume, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
        pstmt.setString(1, donor.getName());
        pstmt.setString(2, donor.getIcNumber());
        pstmt.setDate(3, Date.valueOf(donor.getDob()));
        pstmt.setString(4, donor.getGender());
        pstmt.setInt(5, donor.getAge());
        pstmt.setString(6, donor.getBloodGroup());
        pstmt.setString(7, donor.getEmail());
        pstmt.setString(8, donor.getContactNumber());
        pstmt.setString(9, donor.getAddress());
        pstmt.setDate(10, Date.valueOf(donor.getDonationDate()));
        pstmt.setString(11, donor.getDonationLocation());
        pstmt.setInt(12, donor.getVolume());
        pstmt.setString(13, donor.getRemarks());
        pstmt.executeUpdate();
    }
}

    // Reusable method to populate a PreparedStatement for donor
    private void populateDonorPreparedStatement(PreparedStatement pstmt, Donor donor) throws SQLException {
        pstmt.setString(1, donor.getName());
        pstmt.setString(2, donor.getIcNumber());
        pstmt.setDate(3, Date.valueOf(donor.getDob()));
        pstmt.setString(4, donor.getGender());
        pstmt.setInt(5, donor.getAge());
        pstmt.setString(6, donor.getBloodGroup());
        pstmt.setString(7, donor.getEmail());
        pstmt.setString(8, donor.getContactNumber());
        pstmt.setString(9, donor.getAddress());
        pstmt.setDate(10, Date.valueOf(donor.getDonationDate()));
        pstmt.setString(11, donor.getDonationLocation());
        pstmt.setInt(12, donor.getVolume());
        pstmt.setString(13, donor.getRemarks());
    }

    public boolean icNumberExists(String icNumber) throws SQLException {
    String query = "SELECT COUNT(*) FROM donors WHERE ic_number = ?";
    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
        pstmt.setString(1, icNumber);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
    }
    return false;
}
// Search donor by ID
    public List<Donor> searchDonorById(int id) throws SQLException {
        String query = "SELECT * FROM donors WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                return extractDonorsFromResultSet(rs);
            }
        }
    }

    // Search donor by Name
    public List<Donor> searchDonorByName(String name) throws SQLException {
        String query = "SELECT * FROM donors WHERE name LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, "%" + name + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                return extractDonorsFromResultSet(rs);
            }
        }
    }

    // Extract multiple donors from ResultSet
    private List<Donor> extractDonorsFromResultSet(ResultSet rs) throws SQLException {
        List<Donor> donors = new ArrayList<>();
        while (rs.next()) {
            donors.add(extractDonorFromResultSet(rs));
        }
        return donors;
    }

    // Extract a single donor from ResultSet
    private Donor extractDonorFromResultSet(ResultSet rs) throws SQLException {
        return new Donor(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getString("ic_number"),
            rs.getDate("dob").toLocalDate(),
            rs.getString("gender"),
            rs.getInt("age"),
            rs.getString("blood_group"),
            rs.getString("email"),
            rs.getString("contact_number"),
            rs.getString("address"),
            rs.getDate("donation_date").toLocalDate(),
            rs.getString("donation_location"),
            rs.getInt("volume"),
            rs.getString("remarks")
        );
    }


    // Delete a donor by ID
    public boolean deleteDonor(int id) throws SQLException {
        String query = "DELETE FROM donors WHERE id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/redconnect1", "app", "app");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();
            return rowsDeleted > 0;
        }
    }


    // Check if a donor exists
    public boolean donorExists(int id) throws SQLException {
        String query = "SELECT COUNT(*) FROM DONORS WHERE ID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    public void updateStock(String bloodGroup, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
