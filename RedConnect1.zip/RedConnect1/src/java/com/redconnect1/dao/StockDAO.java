package com.redconnect1.dao;

import com.redconnect1.model.Stock;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StockDAO {
    private static final String URL = "jdbc:derby://localhost:1527/redconnect1";
    private static final String USERNAME = "app";
    private static final String PASSWORD = "app";

    private Connection connection;

    public StockDAO() throws SQLException {
        connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    // Retrieve all stocks from the database
    public List<Stock> getAllStocks() throws SQLException {
        List<Stock> stocks = new ArrayList<>();
        String query = "SELECT BLOOD_GROUP, UNITS FROM STOCK";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Stock stock = new Stock();
                stock.setBloodGroup(rs.getString("BLOOD_GROUP"));
                stock.setUnits(rs.getInt("UNITS"));
                stocks.add(stock);
            }
        }
        return stocks;
    }

    // Decrease stock for a specific blood group
    public boolean decreaseStock(String bloodGroup, int units) throws SQLException {
        String queryCheck = "SELECT UNITS FROM STOCK WHERE BLOOD_GROUP = ?";
        String queryUpdate = "UPDATE STOCK SET UNITS = UNITS - ? WHERE BLOOD_GROUP = ? AND UNITS >= ?";

        try (PreparedStatement checkStmt = connection.prepareStatement(queryCheck)) {
            checkStmt.setString(1, bloodGroup);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                int availableUnits = rs.getInt("UNITS");

                if (availableUnits >= units) {
                    try (PreparedStatement updateStmt = connection.prepareStatement(queryUpdate)) {
                        updateStmt.setInt(1, units);
                        updateStmt.setString(2, bloodGroup);
                        updateStmt.setInt(3, units);
                        updateStmt.executeUpdate();
                        return true;
                    }
                }
            }
        }
        return false; 
    }

// Update stock for a specific blood group
public void updateStock(String bloodGroup, int units) throws SQLException {
    String queryCheck = "SELECT COUNT(*) FROM STOCK WHERE BLOOD_GROUP = ?";
    String queryUpdate = "UPDATE STOCK SET UNITS = UNITS + ? WHERE BLOOD_GROUP = ?";
    String queryInsert = "INSERT INTO STOCK (BLOOD_GROUP, UNITS) VALUES (?, ?)";

    try (PreparedStatement checkStmt = connection.prepareStatement(queryCheck)) {
        checkStmt.setString(1, bloodGroup);
        ResultSet rs = checkStmt.executeQuery();
        rs.next();

        if (rs.getInt(1) > 0) {
            try (PreparedStatement updateStmt = connection.prepareStatement(queryUpdate)) {
                updateStmt.setInt(1, units); 
                updateStmt.setString(2, bloodGroup);
                updateStmt.executeUpdate(); 
            }
        } else {
            try (PreparedStatement insertStmt = connection.prepareStatement(queryInsert)) {
                insertStmt.setString(1, bloodGroup); 
                insertStmt.setInt(2, units); 
                insertStmt.executeUpdate(); 
            }
        }
    }
}

    public Map<String, Integer> getBloodStockLevels() throws SQLException {
        Map<String, Integer> stockLevels = new HashMap<>();
        String query = "SELECT BLOOD_GROUP, UNITS FROM STOCK"; 

        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                stockLevels.put(rs.getString("BLOOD_GROUP"), rs.getInt("UNITS"));
            }
        }
        return stockLevels;
    }


    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
