package com.redconnect1.controller;

import com.redconnect1.dao.StockDAO;
import com.redconnect1.model.Stock;

import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/StockServlet")
public class StockServlet extends HttpServlet {
    private StockDAO stockDAO;

    @Override
    public void init() throws ServletException {
        try {
            stockDAO = new StockDAO();
        } catch (SQLException e) {
            throw new ServletException("Failed to initialize StockDAO", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        try {
            switch (action) {
                case "list":
                    listStocks(request, response);
                    break;
                case "increase":
                    listStocks(request, response, "increase.jsp");
                    break;
                case "print":
                    printStock(request, response);
                    break;
                default:
                    response.sendRedirect("index.jsp");
            }
        } catch (Exception e) {
            handleError(response, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("update".equals(action)) {
            updateStock(request, response);
        } else if ("decrease".equals(action)) {
            decreaseStock(request, response);
        }
    }

private void printStock(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    try {
        // Retrieve all stock details from the database
        List<Stock> stockDetails = stockDAO.getAllStocks(); 
        request.setAttribute("stockDetails", stockDetails); 
        request.getRequestDispatcher("print-stock-details.jsp").forward(request, response); 
    } catch (Exception e) {
        e.printStackTrace();
        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving stock data.");
    }
}


    private void decreaseStock(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String bloodGroup = request.getParameter("bloodGroup");
        String unitsStr = request.getParameter("units");

        if (bloodGroup == null || bloodGroup.isEmpty() || unitsStr == null || unitsStr.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input");
            return;
        }

        try {
            int units = Integer.parseInt(unitsStr);
            boolean success = stockDAO.decreaseStock(bloodGroup, units);

            if (success) {
                response.sendRedirect("StockServlet?action=list");
            } else {
                request.setAttribute("errorMessage", "Not enough stock to decrease.");
                request.getRequestDispatcher("decrease.jsp").forward(request, response);
            }
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Units must be a number");
        } catch (SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }

    private void updateStock(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String bloodGroup = request.getParameter("bloodGroup");
        String unitsStr = request.getParameter("units");

        if (bloodGroup == null || bloodGroup.isEmpty() || unitsStr == null || unitsStr.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input");
            return;
        }

        try {
            int units = Integer.parseInt(unitsStr);
            stockDAO.updateStock(bloodGroup, units);

            listStocks(request, response);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Units must be a number");
        } catch (SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }

    private void listStocks(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        listStocks(request, response, "stock-details.jsp");
    }

    private void listStocks(HttpServletRequest request, HttpServletResponse response, String targetPage)
            throws ServletException, IOException {
        try {
            List<Stock> stocks = stockDAO.getAllStocks();
            request.setAttribute("stockDetails", stocks);
            request.getRequestDispatcher(targetPage).forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Error retrieving stocks", e);
        }
    }

    private void handleError(HttpServletResponse response, Exception e) throws IOException {
        e.printStackTrace();
        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred: " + e.getMessage());
    }

    @Override
    public void destroy() {
        try {
            stockDAO.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
