package com.redconnect1.controller;

import com.redconnect1.dao.DonorDAO;
import com.redconnect1.model.Donor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/SearchDonorServlet")
public class SearchDonorServlet extends HttpServlet {
    private DonorDAO donorDAO;

    @Override
    public void init() throws ServletException {
        donorDAO = new DonorDAO(); 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String searchInput = request.getParameter("search-donor");

        try {
            List<Donor> donors;
            
            if (searchInput.matches("\\d+")) {
                donors = donorDAO.searchDonorById(Integer.parseInt(searchInput));
            } else {
                donors = donorDAO.searchDonorByName(searchInput);
            }

            request.setAttribute("donors", donors);
            request.getRequestDispatcher("update-donor.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error retrieving donor details: " + e.getMessage());
            request.getRequestDispatcher("update-donor.jsp").forward(request, response);
        }
    }
}
