package com.redconnect1.controller;

import com.redconnect1.dao.DonorDAO;
import com.redconnect1.dao.StockDAO;
import com.redconnect1.model.Donor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/DonorServlet")
public class DonorServlet extends HttpServlet {
    private DonorDAO donorDAO;
    private static final Logger LOGGER = Logger.getLogger(DonorServlet.class.getName());

    @Override
    public void init() {
        donorDAO = new DonorDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        try {
            switch (action) {
                case "updateForm":
                    showUpdateForm(request, response);
                    break;
                case "list":
                    listDonors(request, response);
                    break;
                case "delete":
                    deleteDonor(request, response);
                    break;
                case "print":
                    printDonors(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Action not supported.");
            }
        } catch (Exception e) {
            handleError(response, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            switch (action) {
                case "add":
                    addDonor(request, response);
                    break;
                case "update":
                    updateDonor(request, response);
                    break;

                case "delete":
                    deleteDonor(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Action not supported.");
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unhandled exception in doPost: {0}", e.getMessage());
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred.");
        }
    }

 

private void addDonor(HttpServletRequest request, HttpServletResponse response)
        throws IOException, SQLException {
    String icNumber = request.getParameter("icNumber");
    Donor donor = new Donor();
    donor.setName(request.getParameter("name"));
    donor.setIcNumber(icNumber);
    donor.setDob(LocalDate.parse(request.getParameter("dob")));
    donor.setGender(request.getParameter("gender"));
    donor.setAge(Integer.parseInt(request.getParameter("age")));
    donor.setBloodGroup(request.getParameter("bloodGroup"));
    donor.setEmail(request.getParameter("email"));
    donor.setContactNumber(request.getParameter("contactNumber"));
    donor.setAddress(request.getParameter("address"));
    donor.setDonationDate(LocalDate.parse(request.getParameter("donationDate")));
    donor.setDonationLocation(request.getParameter("donationLocation"));
    int volume = Integer.parseInt(request.getParameter("volume"));
    donor.setVolume(volume);
    donor.setRemarks(request.getParameter("remarks"));

    donorDAO.addDonor(donor);

    // Update Stock Details
    String bloodGroup = request.getParameter("bloodGroup");
    StockDAO stockDAO = new StockDAO(); 
    stockDAO.updateStock(bloodGroup, volume); 

    response.sendRedirect("DonorServlet?action=list");
}

private void showUpdateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Donor donor = donorDAO.getDonorById(id);

            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Donor not found.");
                return;
            }

            request.setAttribute("donor", donor);
            request.getRequestDispatcher("update-donor.jsp").forward(request, response);
        } catch (NumberFormatException | SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving donor details.", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving donor details.");
        }
    }

 private void updateDonor(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    try {
        LOGGER.info("Request Parameters: " + request.getParameterMap().toString());

        // Retrieve donor data from the form
        int donorId = Integer.parseInt(request.getParameter("donorId"));
        String name = request.getParameter("name");
        String icNumber = request.getParameter("icNumber");
        LocalDate dob = LocalDate.parse(request.getParameter("dob"));
        String gender = request.getParameter("gender");
        int age = Integer.parseInt(request.getParameter("age"));
        String bloodGroup = request.getParameter("bloodGroup");
        String email = request.getParameter("email");
        String contactNumber = request.getParameter("contactNumber");
        String address = request.getParameter("address");
        LocalDate donationDate = LocalDate.parse(request.getParameter("donationDate"));
        String donationLocation = request.getParameter("donationLocation");
        int volume = Integer.parseInt(request.getParameter("volume"));
        String remarks = request.getParameter("remarks");

        // Log retrieved donor data
        LOGGER.info("Parsed Donor Data: " + donorId + ", " + name + ", " + icNumber + ", " + dob);

        // Create donor object
        Donor donor = new Donor(donorId, name, icNumber, dob, gender, age, bloodGroup, email, contactNumber, address,
                donationDate, donationLocation, volume, remarks);

        // Update donor in the database
        donorDAO.updateDonor(donor);

        // Redirect to donor list page after successful update
        response.sendRedirect("DonorServlet?action=list");
    } catch (NumberFormatException e) {
        LOGGER.log(Level.SEVERE, "Invalid input format: {0}", e.getMessage());
        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid input format.");
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Database error while updating donor: {0}", e.getMessage());
        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error updating donor details.");
    }
}


    private void listDonors(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("donors", donorDAO.getAllDonors());
            request.getRequestDispatcher("all-donor-details.jsp").forward(request, response);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving donor list.", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving donor list.");
        }
    }

    private void deleteDonor(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            if (!donorDAO.donorExists(id)) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Donor not found.");
                return;
            }
            donorDAO.deleteDonor(id);
            response.sendRedirect("DonorServlet?action=list");
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting donor", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error deleting donor.");
        }
    }

    private void printDonors(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("donors", donorDAO.getAllDonors());
            request.getRequestDispatcher("print-donor-details.jsp").forward(request, response);
        } catch (Exception e) {
            handleError(response, e);
        }
    }

  private void handleError(HttpServletResponse response, Exception e) throws IOException {
        LOGGER.log(Level.SEVERE, "Unhandled exception: {0}", e.getMessage());
        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred.");
    }
}