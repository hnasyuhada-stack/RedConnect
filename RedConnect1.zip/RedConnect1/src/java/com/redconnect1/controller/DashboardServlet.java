package com.redconnect1.controller;

import com.redconnect1.dao.StockDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        StockDAO stockDAO = null;
        try {
            stockDAO = new StockDAO();
        } catch (SQLException ex) {
            Logger.getLogger(DashboardServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            Map<String, Integer> stockLevels = stockDAO.getBloodStockLevels();
            request.setAttribute("stockLevels", stockLevels);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Failed to retrieve blood stock levels.");
        }

        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }
}
